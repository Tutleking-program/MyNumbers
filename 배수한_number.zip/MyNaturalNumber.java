public class MyNaturalNumber extends MyInteger {


    public MyNaturalNumber(MyNumber myNumber) {
        super(myNumber);
    }

    public MyNaturalNumber(int number) {
        super(number);
        if(number <= 0){
            throw new IllegalArgumentException("0 보다 큰 자연수를 입력하시오");
        }
    }

    @Override
    public String toString() {
        return String.valueOf(numerator);
    }

}