public class MyInteger extends MyRationalNumber{


    public MyInteger(MyNumber myNumber) {
        super(myNumber);
    }

    public MyInteger(MyNaturalNumber naturalNumber){
        super(naturalNumber.numerator,1);
    }

    public MyInteger(int number) {
        super(number,1);
    }

    @Override
    public String toString() {
        return String.valueOf(numerator);
    }

}
