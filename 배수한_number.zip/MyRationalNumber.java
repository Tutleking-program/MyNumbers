public class MyRationalNumber extends MyNumber{


    public MyRationalNumber(MyNumber myNumber) {
        super(myNumber.numerator,myNumber.denominator);
    }

    public MyRationalNumber(int numerator, int denominator) {
        super(numerator,denominator);
    }

    @Override
    public <T> T add(T operand) {
        return null;
    }

    @Override
    public <T> T minus(T operand) {
        return null;
    }

    @Override
    public <T> T multiple(T operand) {
        return null;
    }

    @Override
    public <T> T divide(T operand) {
        return null;
    }

    public MyRationalNumber(MyRationalNumber myRationalNumber) {
        super(myRationalNumber.numerator,myRationalNumber.denominator);

    }






}
