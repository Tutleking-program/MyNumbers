public abstract class MyNumber  {

    int denominator;
    int numerator;

    public MyNumber( int numerator,int denominator) {
        if(denominator==0){
            throw new IllegalArgumentException("분모를 0으로 사용할 수 없습니다.");
        }
        this.denominator = denominator;
        this.numerator = numerator;
    }


    public abstract <T>T add(T operand);
    public abstract <T>T minus(T operand);
    public abstract <T>T multiple(T operand);
    public abstract <T>T divide(T operand);

    @Override
    public String toString() {
        return "MyNumber{" +
                "numerator=" + numerator +
                ", denominator=" + denominator +
                '}';
    }
}
